/* Programa de ejemplo */
//	LLAMADAS A FUNCION Y CASOS

var int var1;
var chars imprimir
if (!a) return

function int fun1(int var2, chars b){

	var int a
	a = 2
	var2 = a*var2
	var bool hola
	var int var1
	return var2
}

function Imprime ()
{	
    write (a)

    return	// esta instrucción se podría omitir
}	// la función no devuelve nada

fun1(var1, imprimir)

var1 = 32767

Imprime()

