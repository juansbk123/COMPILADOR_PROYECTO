/* Programa de ejemplo 4  */
//	LLAMADAS A FUNCION Y CASOS

var int var1;
var int imprimir 

function int fun1(int var2){
	
	var int a 
	var2 = a*var2
	
	return  var2
}

function Imprime (int a)
{
    write (a)
    return	// esta instrucción se podría omitir
}	// la función no devuelve nada


fun1(imprimir)
var1 = 5
Imprime(var1)