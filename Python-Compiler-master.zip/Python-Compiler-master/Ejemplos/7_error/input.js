/* Programa de ejemplo 7 */
//	ERROR SINTÁCTICO

for (i=1; i <= 10; i = i + 1)
{
	//NO IMPLEMENTACION//zv+=i
	zv+=i
}
