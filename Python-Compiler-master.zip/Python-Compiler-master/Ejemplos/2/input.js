/* Programa de ejemplo 2  */
/* ACCIONES DEL GRUPO 51 */

var int i
var int j
j = 5
// IMPLEMENTACION DEL FOR

for (i = 1; i < 10; i=i+1) {
	i |= j// IMPLEMENTACION DE O LOGICO (|=)
}