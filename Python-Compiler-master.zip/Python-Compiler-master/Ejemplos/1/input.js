/* Programa de ejemplo 1  */
/* Declaración de variables */
var int a
var chars g

var int c 
var bool errrrr
var int h 

a = c + 1 * 5
g = "hola"
errrrr = c < 3

var chars y 
var bool z 

