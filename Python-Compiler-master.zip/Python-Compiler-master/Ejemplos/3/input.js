/* Programa de ejemplo 3  */
//	GLOBALES Y FUNCIONES 

function uno (){
	var int a
	var int b
}

function dos(){
	var int c
	return
}
var int z

function tres(chars c){
	return
}

function cuatro(int a, int b){
	return
}

function int cinco (int a){
	var int b
	return a
}
