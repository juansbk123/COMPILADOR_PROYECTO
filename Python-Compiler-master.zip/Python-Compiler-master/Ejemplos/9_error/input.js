/* Programa de ejemplo 9 */
// error llamada argumentos
var int a
var chars g
var bool errrrr 


function int fun1(int var2){
	
	var int a 
	var2 = a*var2
	
	return  var2
}

fun1()