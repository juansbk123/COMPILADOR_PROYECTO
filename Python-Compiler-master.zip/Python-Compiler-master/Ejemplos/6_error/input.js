/* Programa de ejemplo 6 */
//	ERROR LÉXICO
var int s
var int v0
write ("Escriba su nombre:")
prompt (s)
?
v0 = v2 < v3	/* si v2<v3, v0=v2; en otro caso v0=v3 */
write (s)